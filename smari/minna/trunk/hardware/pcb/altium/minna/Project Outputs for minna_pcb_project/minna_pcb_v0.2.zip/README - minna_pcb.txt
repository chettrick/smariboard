Company: Populate All The Resistors
Design: smari minna v0.2
Date: 2012-08-06

Contact: Chris Hettrick, chris@populatealltheresistors.com

Gerber info:
Inches, 2:5
Embedded Apertures RS274X
Suppress Leading Zeros

File Legend:

Extenstion  |  File Type
-------------------------
.GBL          Bottom Layer
.GBO          Bottom Overlay
.GPB          Bottom Pad Master
.GBP          Bottom Paste Mask
.GBS          Bottom Solder Mask
.GD1          Drill Drawing (and board outline)
.GG1          Drill Guide
.GP1          Internal Plane 1, Power
.GP2          Internal Plane 2, Ground
.GM1          Title Block
.GM2          Board Outline
.GTL          Top Layer
.GTO          Top Overlay
.GPT          Top Pad Master
.GTP          Top Paste Mask
.GTS          Top Solder Mask
.txt          NC Drill File

